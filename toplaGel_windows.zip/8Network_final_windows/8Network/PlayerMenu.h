
#ifndef __PLAYER_MENU_H_INCLUDED__
#define __PLAYER_MENU_H_INCLUDED__


#define WIDTH_SCREEN  900
#define HEIGHT_SCREEN 800

#include <irrlicht.h>
#include <iostream>
#include "progressBar.h"
#include "imports.h"

using namespace irr;

class PlayerMenu
{
public:

	PlayerMenu();
	void run();
	bool settings();

	void setTimer(ITimer* tm);
	ITimer* getTimer();
	void setLevel(int l);
	int  getLevel();
	void setItems(int i);
	int  getItems();
	void setTraps(int t);
	int  getTraps();
	void setItemsTotalScore(int s);
	int  getItemsTotalScore();

	void setCheck(bool newCheck);
	void setCheckMenu();

	IrrlichtDevice* device;
	video::IVideoDriver* driver;
	scene::ISceneManager* smgr;
	gui::IGUIEnvironment* env;

	IProgressBar * pb;
	gui::IGUIButton *game_pad_check;
	gui::IGUIButton *levelButton;
	gui::IGUIButton *item_1;
	gui::IGUIButton *item_2;
	gui::IGUIButton *item_3;
	video::ITexture *image1;
	video::ITexture *image2;
	video::ITexture *imageItem;
	bool check;


	MyEventReceiver myEvent;
	int lastFPS;
	int fps;
	IGUIStaticText *trapMessage;
	IGUIFont *font;

private:

	ITimer* timer;
	int level;
	int items;
	int traps;
	int itemsTotalScore;

};


#endif
