#ifndef IMPORTS_H
#define IMPORTS_H

#include <string.h>
#include <irrlicht.h>
#include "driverChoice.h"
#include "EDriverTypes.h"
#include <IMetaTriangleSelector.h>
#include <IReferenceCounted.h>
#include <iostream>
#include <stdio.h>
#include <iostream>

#ifdef __linux__
#include <sys/time.h>
#endif

using namespace std;
using namespace irr;
using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;



#include <vector>
#include <time.h>
#include <stdlib.h>

#define SERVER_PORT 60000
#define MAX_CLIENTS 4

#define ITEM_SIZE 4
#define LEVEL1_TIME 100
#define LEVEL2_TIME 1000

#define ROOM_NUMBER 94
#define ITEM_NUBMER_END 136 
#define TRAP_NUMBER_END 145
#define MAX_TRAP_NUMBER 9


#define THOUSAND 1000
#define BILLION 1000000L
class Messager {
public:
	int id, x, y, z, flag;

	Messager(int passed_id, int flag_) :id(passed_id), flag(flag_) { }
};



using namespace irr;
using namespace video;
using namespace std;


#ifdef _MSC_VER
#pragma comment(lib, "Irrlicht.lib")
#endif

class MyEventReceiver : public IEventReceiver
{
public:
	// This is the one method that we have to implement
	virtual bool OnEvent(const SEvent& event)
	{
		// Remember whether each key is down or up
		if (event.EventType == irr::EET_KEY_INPUT_EVENT)
			KeyIsDown[event.KeyInput.Key] = event.KeyInput.PressedDown;

		return false;
	}

	// This is used to check whether a key is being held down
	virtual bool IsKeyDown(EKEY_CODE keyCode) const
	{
		return KeyIsDown[keyCode];
	}

	MyEventReceiver()
	{
		for (u32 i = 0; i<KEY_KEY_CODES_COUNT; ++i)
			KeyIsDown[i] = false;
	}

public:
	// We use this array to store the current state of each key
	bool KeyIsDown[KEY_KEY_CODES_COUNT];
};

// ne ise yaradiklarina bak 
enum
{
	// I use this ISceneNode ID to indicate a scene node that is
	// not pickable by getSceneNodeAndCollisionPointFromRay()
	ID_IsNotPickable = 0,

	// I use this flag in ISceneNode IDs to indicate that the
	// scene node can be picked by ray selection.
	IDFlag_IsPickable = 1 << 0,

	// I use this flag in ISceneNode IDs to indicate that the
	// scene node can be highlighted.  In this example, the
	// homonids can be highlighted, but the level mesh can't.
	IDFlag_IsHighlightable = 1 << 1
};


enum {

	PERSON_1 = 1,
	PERSON_2 = 2,
	PERSON_3 = 3,
	PERSON_4 = 4,
	EMPTY = 0

};


enum {
	PLAYER = 1,
	ITEM = 0,
	VISIBLE = 2,
	TIMER = 3,
	BEGIN = 4,
	FINISH = 5,
	ROOM = 6,
	TRAP = 7,
	NONTRAP = 8
};


enum
{
	ID_IsNot = 0,
	ID_Item = 1,
	ID_Trap = 2,
	ID_Room = 3
};

#endif