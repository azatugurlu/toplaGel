#include "SocketConnector.h"


SocketConnector::SocketConnector(int fd)
{
	this->fd = fd;
	connected = true;
}

SocketConnector::~SocketConnector()
{
}

bool SocketConnector::isConnected(){
	return connected;
}

SocketConnector& SocketConnector::operator>>(int& i){
	read((char*)&i, sizeof(int));
	return *this;
}

SocketConnector& SocketConnector::operator>>(float& f){
	read((char*)&f, sizeof(float));
	return *this;
}

SocketConnector& SocketConnector::operator>>(char& c){
	read((char*)&c, sizeof(char));
	return *this;
}

SocketConnector& SocketConnector::operator>>(char* s){
	int size;
	*this >> size;

	if (!connected)return *this;

	read(s, size);
	return *this;
}

SocketConnector& SocketConnector::operator>>(std::string& s){
	int size;
	*this >> size;

	if (!connected)return *this;

	char *cstr = new char[size];
	read(cstr, size);

	s = cstr;

	delete cstr;

	return *this;
}

SocketConnector& SocketConnector::operator<<(int i){
	write((const char*)&i, sizeof(int));
	return *this;
}

SocketConnector& SocketConnector::operator<<(float f){
	write((const char*)&f, sizeof(float));
	return *this;
}

SocketConnector& SocketConnector::operator<<(char c){
	write((const char*)&c, sizeof(char));
	return *this;
}

SocketConnector& SocketConnector::operator<<(const char* s){
	int size = strlen(s) + 1;
	*this << size;

	if (!connected)return *this;

	write(s, size);
	return *this;
}

SocketConnector& SocketConnector::operator<<(std::string s){
	*this << s.c_str();
	return *this;
}

int SocketConnector::write(const char *adr, int size){
	int s = send(fd, adr, size, 0);
	if (s <= 0){
		connected = false;
	}
	return size;
}

int SocketConnector::read(char* adr, int size){
	int s = recv(fd, adr, size, 0);
	if (s <= 0){
		connected = false;
	}
	return size;
}

/*
SocketConnector& SocketConnector::operator>>(PlayerEntity& e){
*this >> e.type;
*this >> e.x;
*this >> e.z;
*this >> e.eid;
*this >> e.meshFlag;

return *this;
}
SocketConnector& SocketConnector::operator>>(ItemEntity& e){
*this >> e.type;
*this >> e.x;
*this >> e.z;
*this >> e.eid;
*this >> e.score;


return *this;
}
SocketConnector& SocketConnector::operator<<(PlayerEntity& e){
*this << e.type;
*this << e.x;
*this << e.z;
*this << e.eid;
*this << e.meshFlag;

return *this;
}
SocketConnector& SocketConnector::operator<<(ItemEntity& e){
*this << e.type;
*this << e.x;
*this << e.z;
*this << e.eid;
*this << e.score;

return *this;
}
*/