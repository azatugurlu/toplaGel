#pragma once

#include "imports.h"
#include "Entity.h"
#include "Server.h"
#include "Client.h"
#include "SerialPort.h"

#include <irrlicht.h>
#include "driverChoice.h"
#include "EDriverTypes.h"
#include <IMetaTriangleSelector.h>
#include <IReferenceCounted.h>
#include "PlayerMenu.h"
#include "TrapInRoom.h"


using namespace irr;

class Game{

public:

	Game();
	void determineScoreOfItems();

	void assignScoreOfItems();
	void assignScoreOfTraps();
	Entity* getItem(scene::ISceneNode* node);
	void createMeta(Entity* e);
	void gameSceneInitiaize(char *IP);
	void gameRun();
	void loadIcon(int index);
	void releaseNode(int keycode);
	void readRoomForClient();
	bool isNear(scene::ICameraSceneNode* camera, scene::ISceneNode* node);
	void traverseItem(int i);
	void trapMessageActive(int score, int playerNum);
	void setTrap();

	core::array<scene::ISceneNode *> nodes;
	scene::IAnimatedMesh* kat2;
	scene::IMeshSceneNode* kat2Node;

	scene::IAnimatedMesh* player;
	scene::IAnimatedMeshSceneNode* aNode;

	scene::ICameraSceneNode* camera;
	scene::IMetaTriangleSelector* meta, *metaRoom;
	scene::ITriangleSelector* selector;


	PlayerMenu playerGui;
	core::array<Entity> items;
	core::array<Entity> traps;
	core::array<Entity> rooms;

	SerialPort *serial;
	AbstractNetwork * network;
	char type;
	


private :
	int pre_item_size=0, pre_player_size=1, pre_invisiblelist=0;
	int pre_room_size = 0; 
	int realaseIndex = -1;
	int trapWaitTime = 0;
};
