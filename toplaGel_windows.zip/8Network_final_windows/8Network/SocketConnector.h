#ifndef ELCI_H
#define ELCI_H

#ifdef _WIN32
#include <winsock.h>
#else
#include <unistd.h>
#include <netinet/in.h>
#endif

#include <iostream>
#include <string>


class SocketConnector
{
public:
	SocketConnector(int fd);
	virtual ~SocketConnector();

	SocketConnector& operator>>(int& i);
	SocketConnector& operator>>(float& f);
	SocketConnector& operator>>(char& c);
	SocketConnector& operator>>(char* s);
	SocketConnector& operator>>(std::string& s);


	SocketConnector& operator<<(int i);
	SocketConnector& operator<<(float f);
	SocketConnector& operator<<(char c);
	SocketConnector& operator<<(const char* s);
	SocketConnector& operator<<(std::string s);


	bool isConnected();
private:
	int write(const char* adr, int size);
	int read(char* adr, int size);

	int fd;

	bool connected;
};

#endif