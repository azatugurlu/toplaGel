
#include "ConnectMenu.h"


ConnectMenu::ConnectMenu()
: createButton(0), joinButton(0), ipBox(0), MenuDevice(0)
{
}

bool ConnectMenu::run()
{

	MenuDevice = createDevice(video::EDT_OPENGL,
		core::dimension2d<u32>(900, 500), 16, false, false, false, this);

	video::IVideoDriver* driver = MenuDevice->getVideoDriver();
	gui::IGUIEnvironment* guienv = MenuDevice->getGUIEnvironment();

	core::stringw str = "Game GYTE";
	MenuDevice->setWindowCaption(str.c_str());

	// set new Skin
	gui::IGUISkin* newskin = guienv->createSkin(gui::EGST_BURNING_SKIN);
	guienv->setSkin(newskin);
	newskin->drop();

	// load font
	gui::IGUIFont* font = guienv->getFont("../media/fonthaettenschweiler.bmp");
	if (font)
		guienv->getSkin()->setFont(font);

	// add panel location
	const s32 leftX = 600;
	// add buttons location
	const s32 d = 50;


	// add tab control
	gui::IGUITabControl* tabctrl = guienv->addTabControl(core::rect<int>(leftX, 10, 900 - 10, 500 - 10),
		0, true, true);
	gui::IGUITab* optTab = tabctrl->addTab(L"Deneme");


	// add button
	createButton = guienv->addButton(core::rect<int>(30, 295 - 5 * d, 200, 324 - 5 * d), optTab, 1, L"Create Game");
	joinButton = guienv->addButton(core::rect<int>(30, 295 - 3 * d, 200, 324 - 3 * d), optTab, 2, L"Join Game");
	ipBox = guienv->addEditBox(L"Enter IP address", core::rect<int>(30, 295 - 4 * d, 200, 324 - 4 * d), false, optTab, 3);

	joinButton->setEnabled(false);


	// logo and background
	bool oldMipMapState = driver->getTextureCreationFlag(video::ETCF_CREATE_MIP_MAPS);
	driver->setTextureCreationFlag(video::ETCF_CREATE_MIP_MAPS, false);

	guienv->addImage(driver->getTexture("../media/toplagel.png"),
		core::position2d<s32>(5, 5));

	video::ITexture* irrlichtBack = driver->getTexture("../media/gyte.jpg");

	driver->setTextureCreationFlag(video::ETCF_CREATE_MIP_MAPS, oldMipMapState);

	// query original skin color
	getOriginalSkinColor();

	// set transparency
	setTransparency();

	// draw all
	while (MenuDevice->run())
	{
		if (MenuDevice->isWindowActive())
		{
			driver->beginScene(false, true, video::SColor(0, 0, 0, 0));

			//background image
			driver->draw2DImage(irrlichtBack,
				core::position2d<int>(0, 0));

			//right panel
			guienv->drawAll();
			driver->endScene();
		}
	}

	MenuDevice->drop();

	//server ba�lan�p
	//ekran� kapatt���nda yollan�r.
	return true;

}


bool ConnectMenu::OnEvent(const SEvent& event)
{

	if (event.EventType == EET_GUI_EVENT)
	{
		s32 id = event.GUIEvent.Caller->getID();

		switch (id)
		{

			//CREATE
		case 1:

			if (event.GUIEvent.EventType == gui::EGET_BUTTON_CLICKED)
			{

				//call server methods
				MenuDevice->closeDevice();
				type = 's';
				return true;
			}

			//JOIN
		case 2:

			if (event.GUIEvent.EventType == gui::EGET_BUTTON_CLICKED)
			{
				
				wcstombs(ipAddress, const_cast<wchar_t*>(ipBox->getText()), IPSIZE);
				std::cout << ipAddress << std::endl;
				type = 'c';
				MenuDevice->closeDevice();

				//ip address yanlissa gui kapatilmadan devam etmeli.
				//call client method with ipAddress
				return true;
			}

		case 3:

			if ((event.GUIEvent.EventType == gui::EGET_EDITBOX_CHANGED) ||
				(event.GUIEvent.EventType == gui::EGET_EDITBOX_ENTER))
			{
				joinButton->setEnabled(true);
				return true;

			}

		}
	}

	return false;
}


void ConnectMenu::getOriginalSkinColor()
{
	irr::gui::IGUISkin * skin = MenuDevice->getGUIEnvironment()->getSkin();
	for (s32 i = 0; i<gui::EGDC_COUNT; ++i)
	{
		SkinColor[i] = skin->getColor((gui::EGUI_DEFAULT_COLOR)i);
	}

}

void ConnectMenu::setTransparency()
{
	irr::gui::IGUISkin * skin = MenuDevice->getGUIEnvironment()->getSkin();

	for (u32 i = 0; i<gui::EGDC_COUNT; ++i)
	{
		video::SColor col = SkinColor[i];

		skin->setColor((gui::EGUI_DEFAULT_COLOR)i, col);
	}
}


