#ifndef CLIENT_H
#define CLIENT_H

#ifdef _WIN32
#include <winsock.h>
#else
#endif

#include <iostream>     //cerr
#include <cstring>      //memset(), memcpy()
#include <pthread.h>

#ifdef _WIN32
#include <winsock.h>
#else
#include <unistd.h>     //socket()
#include <netdb.h>      //hostent, gethostbyname()
#include <netinet/in.h>
#endif

#include "SocketConnector.h"
#include "AbstractNetwork.h"

class Client : public AbstractNetwork{
public:
	Client(const char *ip, int port);
	~Client();

	SocketConnector* getSocketConnector();

	void sendEntity(Entity* entity);
	void recvEntity(Entity* entity);
	

	/* serverdan bilgi gelmesini bekler */
	static void* listener(void *);

	int playerId;


protected:
	SocketConnector* socketFd;
	pthread_t* listenerTid;
};

#endif // CLIENT_H

