#include "Game.h"
#include<string>
Game::Game()
{
	pre_player_size = 0;
	pre_item_size = 0;

}

void Game::gameSceneInitiaize(char *IP, char type)
{
	playerGui.settings();


	kat2 = playerGui.smgr->getMesh("../media/sonkat.irrmesh");
	if (kat2)
		kat2Node = playerGui.smgr->addOctreeSceneNode(kat2->getMesh(0), 0, ID_IsNot);

	kat2Node->setMaterialTexture(0, playerGui.driver->getTexture("../media/wall.jpg"));

	if (kat2Node)
	{
		kat2Node->setPosition(core::vector3df(-1350, -130, -1400));
		selector = playerGui.smgr->createOctreeTriangleSelector(kat2Node->getMesh(), kat2Node, 1024); // collision
		kat2Node->setTriangleSelector(selector);
	}

	//char IP[20];
	//cout << "Server (s), Client (c)" << endl;
	//cin >> type;

	Entity *mainPlayer;



	/******************** Add  Camera ***********************/
	camera = playerGui.smgr->addCameraSceneNodeFPS(0, 100.0f, .5f, ID_IsNot, 0, 0, true, 3.f);
	camera->setPosition(core::vector3df(70, 0, 0)); // y = 50
	camera->setTarget(core::vector3df(70, -10, 0));

	meta = playerGui.smgr->createMetaTriangleSelector();
	meta->addTriangleSelector(kat2Node->getTriangleSelector());


	if (type == 'c'){
		//cout << "Please enter the server IP" << endl;
	//	cin >> IP;
		Client *c = new Client(IP, 4555);
		mainPlayer = c->myEntity;
		network = c;
	}
	else{
		playerGui.smgr->loadScene("../allNodes.irr");
		playerGui.smgr->getSceneNodesFromType(scene::ESNT_MESH, nodes); // Find all nodes


		Server *s = new Server(4555);
		determineScoreOfItems();
		assignScoreOfItems();
		for (int i = 0; i < items.size(); ++i){
			items[i].eid = s->itemList.size();
			items[i].meshFlag = items[i].score;
			s->itemList.push_back(&items[i]);
		}
		

		for (int i = 0; i < traps.size(); ++i){
			traps[i].eid = s->itemList.size();
			traps[i].meshFlag = traps[i].score;
			
			s->itemList.push_back(&traps[i]);
		}
		for (int i = 0; i < rooms.size(); ++i){
			s->roomList.push_back(&rooms[i]);
		}

		mainPlayer = s->myEntity;
		network = s;
	}

	/******************** Add  Player ***********************/
	player = playerGui.smgr->getMesh("../media/c_1.obj");

	if (player)
		network->myEntity->sceneNode = playerGui.smgr->addAnimatedMeshSceneNode(player);

	network->myEntity->sceneNode->setPosition(core::vector3df(70, -60, 0));
	network->myEntity->sceneNode->setAnimationSpeed(15);

	// add shadow
	network->myEntity->sceneNode->addShadowVolumeSceneNode();
	playerGui.smgr->setShadowColor(video::SColor(150, 0, 0, 0));

	// make the model a little bit bigger and normalize its normals
	// because of the scaling, for correct lighting
	network->myEntity->sceneNode->setScale(core::vector3df(30, 30, 30));
	network->myEntity->sceneNode->setMaterialFlag(video::EMF_NORMALIZE_NORMALS, true);
	network->myEntity->sceneNode->setRotation(core::vector3df(0, -90, 0));
	if (meta)
	{
		// kamera duvardan gecemesin diye collisiona eklenir.
		scene::ISceneNodeAnimatorCollisionResponse* anim = playerGui.smgr->createCollisionResponseAnimator(meta,
			network->myEntity->sceneNode, core::vector3df(1, 1, 1), core::vector3df(0, -10, 0), core::vector3df(0, 30, 0));

		meta->drop(); // As soon as we're done with the selector, drop it.
		network->myEntity->sceneNode->addAnimator(anim);
		anim->drop();  // And likewise, drop the animator when we're done referring to it.
	}
	/*serial port start*/
	std::string portname;
	if (!findCorrectPort(portname))
	{
		cerr << "Failed to find arduino port" << endl;
	}
	else
	{
		serial = new SerialPort(portname);
		serial->close();
		if (!serial->open())
		{
			cerr << "Failed to connection port" << endl;
		}
		else
		{
			if (!serial->prepare())
			{
				cerr << "Failed to prepared port" << endl;
			}
			else
			{
				cout << "gamepad hazir" << endl;
			}
		}
	}
	/*serial port start*/
}


void Game::gameRun()
{
	scene::ISceneCollisionManager* collMan = playerGui.smgr->getSceneCollisionManager();

	u32 then = playerGui.getTimer()->getTime();
	double now = playerGui.getTimer()->getTime();
	double frameDeltaTime = (now - then) * 0.001; // Time in seconds
	
	network->timermy -= (frameDeltaTime / 10000);
	playerGui.pb->setProgress(network->timermy);
	int timercounter = 0;
	int timermy = LEVEL1_TIME;
	/*serial port start*/
	GamePad gamepad;
	int MOVEMENT_SPEED = 5;

	/*serial port end*/

	int counter = 0;
	while (playerGui.device->run())
	if (playerGui.device->isWindowActive())
	{
		counter++;
		/**** Timer with PB ****/
		if (type == 's' || type == 'S'){
			if (network->playerList.size() == 2 || network->elapsed_second > 500){ // 2  4 oluck unutmaaaaa
				
				if (network->playerList.size() == 1) break;

				network->timerflag = 1;
				Entity e;
				e.type = BEGIN;
				if (timercounter == 0){
					network->sendEntity(&e);
					timercounter = 1;
				}
			}
		}

		if (network->timerflag){
			now = playerGui.getTimer()->getTime();
			frameDeltaTime = (now - then) * 0.001; // Time in seconds
			timermy -= (frameDeltaTime / 10000);
		}

		playerGui.pb->setProgress(timermy);

		printf("counter : %d\n", counter);
		if (counter > 600 && counter < 900){
			playerGui.setCheck(true);
		}
		else{
			playerGui.setCheck(false);
		}



		playerGui.driver->beginScene(true, true, 0);


		vector<IAnimatedMesh *> players;

		if (pre_player_size < network->playerList.size()){
			printf("player list size %d\n", network->playerList.size());
			for (int i = pre_player_size; i < network->playerList.size(); ++i){
				if (i != 0){
					network->playerList[i]->meshNode = playerGui.smgr->getMesh("../media/c_1.obj");
					network->playerList[i]->sceneNode = playerGui.smgr->addAnimatedMeshSceneNode(player);
					network->playerList[i]->sceneNode->setPosition(core::vector3df(50 + i * 30, -50, -60 - i * 30));
					network->playerList[i]->sceneNode->setAnimationSpeed(15);
					network->playerList[i]->sceneNode->setScale(core::vector3df(50, 50, 60));
		//			createMeta(network->playerList[i]);
				}
			}
			pre_player_size = network->playerList.size();
		}

		if (pre_item_size < network->itemList.size()){
			printf("item list size %d\n", network->itemList.size());
			for (int i = pre_item_size; i < network->itemList.size(); ++i){
				if (type == 's' || type == 'S')
					break;
				char str[100];
				sprintf_s(str, "../media/item%d.png", network->itemList[i]->score);

				scene::ISceneNode* PlanetNode = playerGui.smgr->addEmptySceneNode();
				scene::ISceneNode* Planet = playerGui.smgr->addSphereSceneNode(1.0, 64, PlanetNode, -1, core::vector3df(0, 0, 0), core::vector3df(0, 0, 0),
					core::vector3df(2000, 2000, 2000));
				network->itemList[i]->node = Planet;
				network->itemList[i]->node->setMaterialFlag(video::EMF_LIGHTING, false);
				network->itemList[i]->node->setMaterialType(video::EMT_SOLID);
				network->itemList[i]->node->setMaterialTexture(0, playerGui.driver->getTexture(str));
				network->itemList[i]->node->setScale(core::vector3df(20, 20, 20));
				
				memset(str, '\0', 100);
				sprintf_s(str, "item%d", network->itemList[i]->score);
				network->itemList[i]->node->setName(str);

				network->itemList[i]->updateNode();
				createMeta(network->itemList[i]);

			}
			pre_item_size = network->itemList.size();

		}

		if (pre_invisiblelist < network->invisibleList.size()){
			printf("pre ivisiblelist size %d\n", network->invisibleList.size());
			for (int i = 0; i < network->invisibleList.size(); ++i){
				Entity* e = network->getItemEntity(network->invisibleList[i]->eid);
				e->node->setVisible(false);
			}
			while (network->invisibleList.size() != 0)
				network->invisibleList.pop_back();

			pre_invisiblelist = 0;
		}
		/****  draw   ****/
		playerGui.smgr->drawAll();
		playerGui.env->drawAll();



		// All intersections in this example are done with a ray cast out from the camera to
		// a distance of 1000.  You can easily modify this to check (e.g.) a bullet
		// trajectory or a sword's position, or create a ray from a mouse click position using
		// ISceneCollisionManager::getRayFromScreenCoordinates()
		core::line3d<f32> ray;
		ray.start = camera->getPosition();
		ray.end = ray.start + (camera->getTarget() - ray.start).normalize() * 1000.0f;

		// Tracks the current intersection point with the level or a mesh
		core::vector3df intersection;
		// Used to show with triangle has been hit
		core::triangle3df hitTriangle;

		// This call is all you need to perform ray/triangle collision on every scene node
		// that has a triangle selector, including the Quake level mesh.  It finds the nearest
		// collision point/triangle, and returns the scene node containing that point.
		// Irrlicht provides other types of selection, including ray/triangle selector,
		// ray/box and ellipse/triangle selector, plus associated helpers.
		// See the methods of ISceneCollisionManager
		scene::ISceneNode * selectedItemNode =
			collMan->getSceneNodeAndCollisionPointFromRay(
			ray,
			intersection, // This will be the position of the collision
			hitTriangle, // This will be the triangle hit in the collision
			ID_Item, // This ensures that only nodes that we have
			// set up to be pickable are considered
			0); // Check the entire scene (this is actually the implicit default)

		// If the ray hit anything, move the billboard to the collision position
		// and draw the triangle that was hit.
		if (selectedItemNode)
		{
			//std::cout << selectedSceneNode->getName() << std::endl;
			// We need to reset the transform before doing our own rendering.
			playerGui.driver->setTransform(video::ETS_WORLD, core::matrix4());

		}
		/*serial port start*/
		serial->getValue(&gamepad);

		/*serial port end*/
		core::vector3df nodePosition = network->myEntity->sceneNode->getPosition();
		core::vector3df nodeRotation = network->myEntity->sceneNode->getRotation();
		core::vector3df cameraPosition = camera->getPosition();
		if (gamepad.rightButton == 0 && gamepad.rightPot>50)
		{
			int x = 0, z = 0;
			if (gamepad.leftPot <= 45)
			{
				z = MOVEMENT_SPEED;
				x = MOVEMENT_SPEED * gamepad.leftPot / 45;
			}
			else if (gamepad.leftPot < 90)
			{
				x = MOVEMENT_SPEED;
				z = MOVEMENT_SPEED * (90 - gamepad.leftPot) / 45;
			}
			else if (gamepad.leftPot < 135)
			{
				x = MOVEMENT_SPEED;
				z = -MOVEMENT_SPEED * (gamepad.leftPot - 90) / 45;
			}
			else if (gamepad.leftPot < 180)
			{
				z = -MOVEMENT_SPEED;
				x = MOVEMENT_SPEED * (180 - gamepad.leftPot) / 45;
			}
			else if (gamepad.leftPot < 225)
			{
				z = -MOVEMENT_SPEED;
				x = -MOVEMENT_SPEED * (gamepad.leftPot - 180) / 45;
			}
			else if (gamepad.leftPot < 270)
			{
				x = -MOVEMENT_SPEED;
				z = -MOVEMENT_SPEED * (270 - gamepad.leftPot) / 45;
			}
			else if (gamepad.leftPot < 315)
			{
				x = -MOVEMENT_SPEED;
				z = MOVEMENT_SPEED * (gamepad.leftPot - 270) / 45;
			}
			else if (gamepad.leftPot <= 360)
			{
				z = MOVEMENT_SPEED;
				x = -MOVEMENT_SPEED * (360 - gamepad.leftPot) / 45;
			}
			nodePosition.Z += z;
			cameraPosition.Z += z;
			nodePosition.X += -x;
			cameraPosition.X += -x;
			network->myEntity->sceneNode->setPosition(nodePosition);
			vector3df pos = nodePosition;
			pos.Y += 80;
			camera->setPosition(pos);
		}
		nodeRotation.Y = gamepad.leftPot;
		vector3df t = nodeRotation;
		t.Y += 360;
		network->myEntity->sceneNode->setRotation(-nodeRotation);
		camera->setRotation(-nodeRotation);

		if (gamepad.leftButton) {

			if (selectedItemNode != NULL){
				printf("n ye bast�n hayvan\n");

				Entity * e, e_;
				if ((e = getItem(selectedItemNode)) != NULL){
					printf("�st�ne buraya girdin\n");
					e_.eid = e->eid;
					e_.type = VISIBLE;
					e_.meshFlag = VISIBLE;
					e_.score = VISIBLE;
					printf("send entitiy: e type: %d\n", e_.type);
					network->sendEntity(&e_);
				}
			}
		}

		/*serial port end*/
		if (playerGui.myEvent.IsKeyDown(irr::KEY_KEY_N)) {

			if (selectedItemNode != NULL){

				Entity * e, e_;
				if ((e = getItem(selectedItemNode)) != NULL){
					e_.eid = e->eid;
					e_.type = VISIBLE;
					e_.meshFlag = VISIBLE;
					e_.score = VISIBLE;
					network->sendEntity(&e_);
				}
			}
		}
		if (playerGui.myEvent.IsKeyDown(irr::KEY_KEY_M)) {

			releaseItem();
		}

		playerGui.driver->endScene();

		/***** window header *****/
		playerGui.fps = playerGui.driver->getFPS();

		if (playerGui.lastFPS != playerGui.fps)
		{
			core::stringw str = L"Project 2 - Group 8 [ FPS: ";
			str += playerGui.fps;
			str += "]";
			playerGui.device->setWindowCaption(str.c_str());
			playerGui.lastFPS = playerGui.fps;
		}

	}

	playerGui.device->drop();

}




// sadece server yapicakk
void Game::determineScoreOfItems() {

	srand((unsigned)time(NULL));

	for (u32 i = 0; i < ROOM_NUMBER; ++i) {
		Entity room;
	
		room.type = ROOM;
		room.node = nodes[i];
		room.eid = atoi(nodes[i]->getName());
		room.x = nodes[i]->getPosition().X;
		room.y = nodes[i]->getPosition().Y;
		room.z = nodes[i]->getPosition().Z;

		rooms.push_back(room);
	}
	int j = 0;
	for (u32 i = ROOM_NUMBER; i < ITEM_NUBMER_END; ++i) {

		Entity item;
		u32 score;

			score = 1 + rand() % 10;

		char name[8];
		sprintf_s(name, "item%d", j + 1);
		++j;
		nodes[i]->setID(ID_Item);
		nodes[i]->setName(name);

		item.node = nodes[i];
		item.x = nodes[i]->getPosition().X;
		item.y = nodes[i]->getPosition().Y;
		item.z = nodes[i]->getPosition().Z;


		item.score = score;

		items.push_back(item);

	}
	srand(time(NULL));
	int index__ = 1 + (rand() % 4);
	int indexx_counter = 0;
	for (u32 i = ITEM_NUBMER_END; i < MAX_TRAP_NUMBER; ++i) {

		Entity item;
		u32 score;

		score = 11 + (rand() % 3);


		char name[8];
		sprintf_s(name, "item%d", j + 1);
		++j;

		nodes[i]->setID(ID_Item);
		nodes[i]->setName(name);


		item.node = nodes[i+i*index__];
		item.x = nodes[i]->getPosition().X;
		item.y = nodes[i]->getPosition().Y;
		item.z = nodes[i]->getPosition().Z;
		item.type = ITEM;

		item.score = score;

		traps.push_back(item);
	}

}

void Game::assignScoreOfItems() {

	for (u32 i = 0; i < items.size(); ++i) {

		char str[100];
		sprintf_s(str, "../media/item%d.png", items[i].score); /*item score*/

		items[i].node->setMaterialTexture(0, playerGui.driver->getTexture(str));

		scene::ITriangleSelector* selector = playerGui.smgr->createTriangleSelectorFromBoundingBox(items[i].node); // collision
		items[i].node->setTriangleSelector(selector);

		if (selector)
		{
			if (meta == NULL)
				printf("NULL A DENK GELD�M\N");
			// Add it to the meta selector, which will take a reference to it
			meta->addTriangleSelector(selector);
			// And drop my reference to it, so that the meta selector owns it.
			selector->drop();
		}

	}

}

void Game::assignScoreOfTraps() {

	for (u32 i = 0; i < traps.size(); ++i) {

		char str[100];
		sprintf_s(str, "../media/item%d.png", traps[i].score); /*item score*/

		traps[i].node->setMaterialTexture(0, playerGui.driver->getTexture(str));

		scene::ITriangleSelector* selector = playerGui.smgr->createTriangleSelectorFromBoundingBox(traps[i].node); // collision
		traps[i].node->setTriangleSelector(selector);

		if (selector)
		{
			if (meta == NULL)
				printf("NULL A DENK GELD�M\N");
			// Add it to the meta selector, which will take a reference to it
			meta->addTriangleSelector(selector);
			// And drop my reference to it, so that the meta selector owns it.
			selector->drop();
		}

	}

}


Entity* Game::getItem(scene::ISceneNode* node) {

	char path[100];

	if (node == NULL)
		return NULL;

	u32 index = std::atoi(node->getName() + 4) - 1;
	bool success;

	Entity* e = NULL;
	for (int i = 0; i < network->itemList.size(); ++i){
		if (node == network->itemList[i]->node){
			e = network->itemList[i];
			break;
		}
		
	}
	int score = 0;
	if (e->score >10)
		score = e->score -= 10;
	else
		score = e->score;
	sprintf_s(path, "../media/item%d_min.png", score);
	//	printf("items eid : %d, itemlist eid: %d\n", items[index].eid, e->eid);

	if (network->itemPackCounter < 3){
		network->itemPack[network->itemPackCounter] = e;
		network->itemPackCounter += 1;
		success = true;
	}
	else
		return NULL;




	if (success) {

		node->setVisible(false);
		meta->removeTriangleSelector(node->getTriangleSelector());
		playerGui.imageItem = playerGui.driver->getTexture(path);

		switch (network->itemPackCounter){

		case 1:
			playerGui.item_1->setImage(playerGui.imageItem);
			break;

		case 2:
			playerGui.item_2->setImage(playerGui.imageItem);
			break;

		case 3:
			playerGui.item_3->setImage(playerGui.imageItem);
			break;

		default:
			break;

		}

	}

	return e;
}

void Game::releaseItem() {

	/*Entity item = person.removeItem();
	//std::cout << "dddddddd" << std::endl;

	if (item.getScore() != 0) {

	u32 index = std::atoi(item.getISceneNode()->getName() + 4) - 1;
	items[index].getISceneNode()->setPosition(core::vector3df(camera->getPosition().X + 10, camera->getPosition().Y, camera->getPosition().Z));
	items[index].getISceneNode()->setVisible(true);

	scene::ITriangleSelector* selector = playerGui.smgr->createTriangleSelectorFromBoundingBox(items[index].getISceneNode()); // collision
	items[index].getISceneNode()->setTriangleSelector(selector);

	if (selector)
	{
	// Add it to the meta selector, which will take a reference to it
	meta->addTriangleSelector(selector);
	// And drop my reference to it, so that the meta selector owns it.
	selector->drop();
	}

	playerGui.imageItem = playerGui.driver->getTexture("../media/freeItem.png");

	switch (person.getItems().size()){

	case 0:
	playerGui.item_1->setImage(playerGui.imageItem);
	break;

	case 1:
	playerGui.item_2->setImage(playerGui.imageItem);
	break;

	case 2:
	playerGui.item_3->setImage(playerGui.imageItem);
	break;

	default:
	break;

	}

	}*/
}


void Game:: createMeta(Entity* e){
	scene::ITriangleSelector* selector = NULL;
	if (e->type == ITEM || e->type == VISIBLE){
		 selector = playerGui.smgr->createTriangleSelectorFromBoundingBox(e->node); // collision
		e->node->setTriangleSelector(selector);
	}if (e->type == PLAYER){
		selector = playerGui.smgr->createTriangleSelectorFromBoundingBox(e->sceneNode); // collision
		e->node->setTriangleSelector(selector);
	}

	if (selector)
	{
		if (meta == NULL)
			printf("NULL A DENK GELD�M\N");
		// Add it to the meta selector, which will take a reference to it
		meta->addTriangleSelector(selector);
		// And drop my reference to it, so that the meta selector owns it.
		selector->drop();
	}
}

void Game::traverseItem(){

	video::ITexture *oldImage, *newImage;
	char pathNew[100], pathOld[100];

	switch (network->itemTraverseCounter){

	case 1:
		sprintf(pathNew, "../media/item%d_min.png", network->itemPack[0]->meshFlag);
		newImage = playerGui.driver->getTexture(pathNew);
		playerGui.item_1->setImage(newImage);
		sprintf(pathOld, "../media/item%d_min_tr.png", network->itemPack[0]->meshFlag);
		oldImage = playerGui.driver->getTexture(pathOld);
		playerGui.item_3->setImage(oldImage);
		break;

	case 2:
		sprintf(pathNew, "../media/item%d_min.png", network->itemPack[1]->meshFlag);
		newImage = playerGui.driver->getTexture(pathNew);
		playerGui.item_2->setImage(newImage);
		sprintf(pathOld, "../media/item%d_min_tr.png", network->itemPack[1]->meshFlag);
		oldImage = playerGui.driver->getTexture(pathOld);
		playerGui.item_1->setImage(oldImage);
		break;

	case 3:
		sprintf(pathNew, "../media/item%d_min.png", network->itemPack[2]->meshFlag);
		newImage = playerGui.driver->getTexture(pathNew);
		playerGui.item_3->setImage(newImage);
		sprintf(pathOld, "../media/item%d_min_tr.png", network->itemPack[2]->meshFlag);
		oldImage = playerGui.driver->getTexture(pathOld);
		playerGui.item_2->setImage(oldImage);
		break;

	default:
		break;

	}

	if (network->itemTraverseCounter == 3)
		network->itemTraverseCounter = 1;
	else
		++network->itemTraverseCounter;

}