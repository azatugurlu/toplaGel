#pragma once

#include <vector>
#include <cstring>
#include <iostream>
#include <string>
#include "TrapInRoom.h"

using namespace std;

#include <irrlicht.h>
using namespace irr;

using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;

#include "Entity.h"

class AbstractNetwork  {
public:
	AbstractNetwork(): myEntity(NULL){
		printf("geldin mi\n");
		itemPackCounter = 0;
		 timerflag = 0;
		 playerRoomList.push_back(core::vector3df(36.8, -50 ,-3016.8));
		 paralelYapi.push_back(0);
		 playerRoomList.push_back(core::vector3df(-2831.697266, -50 , -2904.974121));
		 paralelYapi.push_back(8);
		 playerRoomList.push_back(core::vector3df(-2696.698242,-50 ,-738.647217 ));
		 paralelYapi.push_back(16);
		 playerRoomList.push_back(core::vector3df(-162.79187,-50 ,-252.62204 ));
		 paralelYapi.push_back(23);

	}

	virtual void sendEntity(Entity* entity) = 0;
	virtual void recvEntity(Entity* entity) = 0;

	Entity* getPlayerEntity(int eid){ 
		for (int i = 0; i < playerList.size(); i++){
			Entity* e = playerList[i];
			if (e->eid == eid){
				return e;
			}
		}

		return NULL;
	}

	Entity* getItemEntity(int eid){
		for (int i = 0; i < itemList.size(); i++){
			Entity* e = itemList[i];
			if (e->eid == eid){
				return e;
			}
		}

		return NULL;
	}

	unsigned long difTime(struct timeval tStart, struct timeval tFinish){
		return (BILLION * (tFinish.tv_sec - tStart.tv_sec) +
			THOUSAND * (tFinish.tv_usec - tStart.tv_usec));
	}

	Entity* myEntity;

	vector<Entity*> playerList;
	vector<Entity*> itemList;
	vector<Entity*> roomList;
	vector<Entity*> invisibleList;
	vector<core::vector3df>  playerRoomList;
	vector<int>  paralelYapi;
	int myRoomIndex;
	int currentRoomIndex;

	TrapInRoom trapInRooms[46];

	Entity* itemPack[3];
	int itemPackCounter ;
	int timerflag;
	int gameTime;
	int itemTraverseCounter = 1;
	int totalScore = 0;

	
};

