#ifndef TRAP_IN_ROOM_H
#define TRAP_IN_ROOM_H

class TrapInRoom {

public:
	TrapInRoom();
	TrapInRoom(bool flag, int type);

	void setFlag(bool flag);
	void setType(int type);

	bool getFlag() const;
	int getType() const;
	int eid;
private:
	bool flag;
	int type;
};
#endif