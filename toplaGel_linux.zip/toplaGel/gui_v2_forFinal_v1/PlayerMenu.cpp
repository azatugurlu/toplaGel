

#include "PlayerMenu.h"

PlayerMenu::PlayerMenu() : level(0), items(0), traps(0), itemsTotalScore(0), lastFPS(-1), fps(0)
{
}

ITimer*  PlayerMenu::getTimer()
{
	return timer;
}

void PlayerMenu::setTimer(ITimer* tm)
{
	timer = tm;
}

void PlayerMenu::setLevel(int l)
{
	level = l;
}

int PlayerMenu::getLevel()
{
	return level;
}

void PlayerMenu::setItems(int i)
{
	items = i;
}

int  PlayerMenu::getItems()
{
	return items;
}

void PlayerMenu::setTraps(int t)
{
	traps = t;
}

int  PlayerMenu::getTraps()
{
	return traps;
}

void PlayerMenu::setItemsTotalScore(int s)
{
	itemsTotalScore = s;
}

int  PlayerMenu::getItemsTotalScore()
{
	return itemsTotalScore;
}


void PlayerMenu::setCheck(bool newCheck){
	this->check = newCheck;
	setCheckMenu();
}

void PlayerMenu::setCheckMenu(){
	if (check){
		game_pad_check->setVisible(true);
	}
	else{
		game_pad_check->setVisible(false);
	}
}


bool PlayerMenu::settings()
{

	/*************************** Initialize *********************/
	device = createDevice(video::EDT_OPENGL,
		core::dimension2d<u32>(WIDTH_SCREEN, HEIGHT_SCREEN), 16, false, false, false, &myEvent);
	driver = device->getVideoDriver();
	smgr = device->getSceneManager();

	env = device->getGUIEnvironment();
	gui::IGUISkin* skin = env->createSkin(gui::EGST_BURNING_SKIN);
	gui::IGUIFont* font = env->getFont("../media/fonthaettenschweiler.bmp");

	env->setSkin(skin);
	skin->drop();

	if (font)
		skin->setFont(font);

	/*************************** Window Properties *********************/
	setTimer(device->getTimer());

	pb = new IProgressBar(env, rect<s32>(600, 12, 760, 42));
	item_1 = env->addButton(core::rect<int>(40, 10, 120, 90), 0, 1, L"");
	levelButton = env->addButton(core::rect<int>(780, 12, 858, 40), 0, 1, L"");
	item_2 = env->addButton(core::rect<int>(140, 10, 220, 90), 0, 1, L"");
	item_3 = env->addButton(core::rect<int>(240, 10, 320, 90), 0, 1, L"");
	game_pad_check = env->addButton(core::rect<int>(300, 250, 590, 640), 0, 1, L"");
	levelButton->setEnabled(false);
	item_1->setEnabled(false);
	item_2->setEnabled(false);
	item_3->setEnabled(false);
	game_pad_check->setEnabled(false);
	trapMessage = env->addStaticText(L"", rect<s32>(560, 120, 860, 180), true);
	trapMessage->setText(L" ");
	font = device->getGUIEnvironment()->getFont("../media/font.png");
	trapMessage->setOverrideFont(font);

	image1 = driver->getTexture("../media/level1.png");
	image2 = driver->getTexture("../media/kol_bozuk.png");
	levelButton->setImage(image1);
	game_pad_check->setImage(image2);
	return true;
}


