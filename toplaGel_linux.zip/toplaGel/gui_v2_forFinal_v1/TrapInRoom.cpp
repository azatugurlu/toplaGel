#include "TrapInRoom.h"

TrapInRoom::TrapInRoom() {
	
	this->flag = false;
	this->type = -1;
}

TrapInRoom::TrapInRoom(bool flag, int type) {

	this->flag = flag;
	this->type = type;
}

void TrapInRoom::setFlag(bool flag) {
	
	this->flag = flag;
}

void TrapInRoom::setType(int type) {

	this->type;
}

bool TrapInRoom::getFlag() const {

	return flag;
}

int TrapInRoom::getType() const {
	
	return type;
}