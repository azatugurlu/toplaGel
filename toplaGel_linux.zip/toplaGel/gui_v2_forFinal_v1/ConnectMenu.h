
#ifndef __CONNECT_MENU_H_INCLUDED__
#define __CONNECT_MENU_H_INCLUDED__

#include <irrlicht.h>
#include <iostream>

#define IPSIZE 20

using namespace irr;


class ConnectMenu : public IEventReceiver
{
public:

	ConnectMenu();

	bool run();

	virtual bool OnEvent(const SEvent& event);
	char ipAddress[IPSIZE];
	char type;

private:

	gui::IGUIButton* createButton;
	gui::IGUIButton* joinButton;
	gui::IGUIEditBox* ipBox;

	IrrlichtDevice *MenuDevice;

	video::SColor SkinColor[gui::EGDC_COUNT];
	void getOriginalSkinColor();
	void setTransparency();
};

#endif
