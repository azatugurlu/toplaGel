#include "Server.h"

Server::Server(int port) : AbstractNetwork(){
	this->port = port;



	//Open socket
	if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		std::cerr << "Socket could not open !!!";
	}
//	gettimeofday(&startTime, NULL);

	//Set servAdrr
	struct sockaddr_in servAddr;
	servAddr.sin_family = AF_INET;
	servAddr.sin_addr.s_addr = INADDR_ANY;
	servAddr.sin_port = htons(port);

	//Open port
	if (bind(fd, (struct sockaddr *) &servAddr, sizeof(servAddr)) < 0) {
		std::cerr << "Could not bind !!!";
	}

	//Listen
	listen(fd, 5);

	//start sekreter
	pthread_create(&listenMySocket, NULL, waitAccept, this);

	lastEntityId = 0;

	playerRoomIndex = 0;
	//create entity for itself
	Entity* entity = new Entity;
	entity->eid = playerList.size();
	entity->type = PLAYER;
	playerList.push_back(entity);

	/*yaratilan main player icin random bir oyuncu flag i alindi*/
	createMeshFlagForNewNode(entity->eid, entity->type);
	entity->x = playerRoomList[playerRoomIndex].X;
	entity->y = playerRoomList[playerRoomIndex].Y;
	entity->z = playerRoomList[playerRoomIndex].Z;

	playerRoomCounter += 1;
	myRoomIndex = paralelYapi[playerRoomIndex];
	currentRoomIndex = myRoomIndex;

	/*yaratilan entity main player a atandi*/
	myEntity = entity;

	lock = PTHREAD_MUTEX_INITIALIZER;
}

Server::~Server(){

}

SocketConnector* Server::waitClient(){
	struct sockaddr_in clientAddr;

#ifdef _WIN32
	int clientLen = sizeof(clientAddr);
#else
	socklen_t clientLen = sizeof(clientAddr);
#endif

	int socketFD = accept(fd, (struct sockaddr *) &clientAddr, &clientLen);

	return new SocketConnector(socketFD);
}

void* Server::waitAccept(void* _server){
	Server* server = (Server*)_server;

	while (1){
		/*bir client ba�lanan kadar bu fonksiyon icinde bekletildi.*/
		SocketConnector* sd = server->waitClient();
		/*yani baglanan client icin yaratilen socket descriptor*/
		printf("server gametime %d\n", server->gameTime);
		if (server->gameTime < LEVEL1_TIME*4){
			printf("game time is %d----------\n", server->gameTime);
			server->newClientComming(sd);
		}
		else{
			Entity e;
			e.type = FINISH;
			*sd << e;
		}
	}
}

void Server::newClientComming(SocketConnector* sc){
	/*client icin bir thread yaratilacak ve bu threade argumanlar pass edilmesi icin
	bu aamalar yapildi.*/
	ThreadData* threadData = new ThreadData;
	threadData->server = this;
	threadData->sc = sc;
	sprintf(threadData->name, "Client %d", playerList.size());

	pthread_mutex_lock(&lock);

	cout << "Yeni client: " << threadData->name << endl;

	pthread_t *scTid = new pthread_t;
	socetConnectorArr.push_back(sc);

	pthread_create(scTid, NULL, handleClient, (void*)threadData);
}

void Server::sendEntity(Entity* entity){
	pthread_mutex_lock(&(lock));

	Entity * sendData;


	if (entity->type == 1){
		sendData = getPlayerEntity(entity->eid);
	}
	else{
		sendData = getItemEntity(entity->eid);
	}
	if (entity->type == VISIBLE)
		sendData->type = VISIBLE;
	if (sendData == NULL)
		sendData = new Entity;

	if (entity->type == BEGIN ){
		sendData->type = BEGIN;
		printf("begin gonderildi\n");
	}
	if (entity->type == FINISH){
		sendData->type = FINISH;
	}
	if (entity->type == TIMER){
		sendData->type = TIMER;
	}
	if (entity->type == TRAP){
		sendData->type = TRAP;
		sendData->index = entity->index;
		sendData->score = entity->score;
		sendData->eid = entity->eid;
	}


	for (int i = 0; i < socetConnectorArr.size(); i++){
		SocketConnector* sc = socetConnectorArr[i];
		if (sendData == NULL)
			break;
		printf("send entity is eid %d type : %d x:%f, y:f, z:f\n", sendData->eid, sendData->type, sendData->x, sendData->y, sendData->z);

		*sc << *sendData;
	}

	pthread_mutex_unlock(&(lock));
}

void Server::recvEntity(Entity* entity){

	Entity *e;

	if (entity->type == PLAYER){
		e = getPlayerEntity(entity->eid);
		e->update(entity);
	}
	else if(entity->type == ITEM){
		e = getItemEntity(entity->eid);
		e->update(entity);
	}
	else if (entity->type == FINISH){
		scoreArr.push_back(entity);
	}
	else if (entity->type == TRAP){
		printf("trap aldim server\n");
		trapInRooms[entity->index].setFlag(true);
		trapInRooms[entity->index].setType(entity->score - 10);
		trapInRooms[entity->index].eid = entity->eid;
	}
	else{
		e = getItemEntity(entity->eid);
		invisibleList.push_back(e);
	}


	sendEntity(entity);
}

void* Server::handleClient(void* serverClientData){
	ThreadData* threadData = (ThreadData*)serverClientData;

	Server* server = threadData->server;
	SocketConnector* sc = threadData->sc;
	char* name = threadData->name;

	cout << "New client: " << name << endl;

	// create entity
	Entity* entity = new Entity;
	entity->eid = server->playerList.size();
	server->playerList.push_back(entity);
	entity->type = PLAYER;
	server->createMeshFlagForNewNode(entity->eid,entity->type);

	server->playerRoomIndex = (server->playerRoomIndex + 1) % 4;

	entity->x = server->playerRoomList[server->playerRoomIndex].X;
	entity->y = server->playerRoomList[server->playerRoomIndex].Y;
	entity->z = server->playerRoomList[server->playerRoomIndex].Z;
	entity->index = server->playerRoomIndex;

	server->playerRoomCounter += 1;
	// send player id to client
	*sc << *entity;
	entity->type = ROOM;
	*sc << *entity;
	printf("*****player list size: %d\n", server->playerList.size());

	// send current scene to client
	for (int i = 0; i < server->playerList.size(); i++){
			Entity* entity = server->playerList[i];
			*sc << *entity;

	}
	// send current scene to client
	for (int i = 0; i < server->itemList.size(); i++){
		Entity* entity = server->itemList[i];
		*sc << *entity;
	}


/*	Entity e;
	e.type = TIMER;
	e.score = timermy;
	*sc << e;
	*/
	pthread_mutex_unlock(&(server->lock));

	server->sendEntity(entity);

	// wait for client updates
	while (1){
		Entity e;
		*sc >> e;

		if (!sc->isConnected()){
			cout << "Disconnected client: " << name << endl;
			break;
		}

		server->recvEntity(&e);
	}

	return NULL;
}


void Server::createMeshFlagForNewNode(int eid, int type){
	Entity *entity=NULL;

	if (type == 1){
		entity = getPlayerEntity(eid);
		if (eid == 0){
			srand(time(NULL));
			entity->meshFlag = rand() % 4;
		}
		entity->meshFlag = (playerList[playerList.size() - 1]->meshFlag + 1) % 4;
	}
	else{
		entity = getItemEntity(eid);
		entity->meshFlag = entity->score;
	}

	cout << "Node created for" << eid << endl;
}
