#include "Client.h"

Client::Client(const char *ip, int port) : AbstractNetwork(){
#ifdef _WIN32
	WSADATA wsaData = { 0 };
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0){ std::cerr << "WSAStartup failed: %d\n"; }
#endif

	//Open socket
	int fd;
	if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		std::cerr << "Socket could not open !!!\n";
	}

	struct hostent *server = gethostbyname(ip);
	if (server == NULL)
	{
		std::cerr << "ERROR, no such host\n";
	}

	// Set serverAdress
	struct sockaddr_in serverAddress;
	memset(&serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	memcpy((char *)&serverAddress.sin_addr, server->h_addr, server->h_length);
	serverAddress.sin_port = htons(port);

	if (connect(fd, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0)
	{
		std::cerr << "Could not connect\n";
	}
	else{
		printf("Connect to Server\n");
	}

	socketFd = new SocketConnector(fd);

	listenerTid = new pthread_t;
	playerId = -1;
	pthread_create(listenerTid, NULL, listener, (void*)this);
}

Client::~Client()
{
}

SocketConnector* Client::getSocketConnector(){
	return socketFd;
}

void Client::sendEntity(Entity* entity){
	*socketFd << *entity;
}

void Client::recvEntity(Entity* entity){


	Entity* e = NULL;
	if (entity->type == 1){
		e = getPlayerEntity(entity->eid);
		if (e != NULL)
		printf("eid: %d type:%d, x: %f, z: %f\n", entity->eid, entity->type, entity->x, entity->z);	
		
	}
	else if (entity->type == ITEM || entity->type ==VISIBLE)
		e = getItemEntity(entity->eid);
	else if (entity->type == BEGIN){
		printf("begin adim ---------\n");
		timerflag = 1;
		return;
	}


	//entity varsa update et, yoksa olu�tur
	if (e != NULL && entity->type != VISIBLE){
		e->update(entity);
	}
	else{
		if (entity->type == TRAP){
			printf("trap kuruldu index %d\n", entity->index);
			trapInRooms[entity->index].setFlag(true);
			trapInRooms[entity->index].setType(entity->score - 10);
			trapInRooms[entity->index].eid = entity->eid;
			return;
		}
		if (entity != NULL){
			if (entity->type == ITEM){
				printf("listeye item koydum**************\n");
				e = new Entity;
				e->type = ITEM;
				e->meshFlag = entity->meshFlag;
				e->score = entity->score;
				e->update(entity);

				if (e->score > 10)
					printf("trep aldim ve score  u %d\n", e->score);


				itemList.push_back(e);
			}
			else if (entity->type == PLAYER){
				printf("listeye player koydum************\n");
				e = new Entity;
				e->meshFlag = entity->meshFlag;
				myRoomIndex = entity->index;
				currentRoomIndex = entity->index;
				printf("---------------------------\n\n\nodamin indexi :%d, x: %f z: %f \n\n\n", myRoomIndex, entity->x, entity->z);
				e->update(entity);
				playerList.push_back(e);

				if (playerId == e->eid){
					printf("main player x: %f, y:%f, z:%f\n", entity->x, entity->y, entity->z);
					myEntity->node = e->node;
				}
			}
			else if (entity->type == TIMER){
				gameTime = entity->score;
			}
			else if (entity->type == FINISH){
				printf("Program finished oldu\n");
			}
			else if (entity->type == ROOM){
				if (entity->meshFlag == -1){
					printf("bos\n");
				}
				
			}
			else if (entity->type == BEGIN){
				e = new Entity;
				
				printf("++++++++++++++++BEGIN+++++++++++++++\n");
				e->type = BEGIN;
				timerflag = 1;
			}
			else{
				printf("++++++++invisible list e koydum\n");
				invisibleList.push_back(e);
				printf("buraya geldim client recv\n");
			}
		}
	}
}

void* Client::listener(void* arg){
	Client* client = (Client*)arg;
	SocketConnector* sc = client->getSocketConnector();
	Entity e;

	//get player id
	if (client->myEntity == NULL)
		client->myEntity = new Entity;



	
	*sc >> *(client->myEntity);

	printf("\n\n\n-----> ald�m e type : %d\n\n\n", e.type);

	if (e.type == FINISH)
		client->gameTime = e.score;
	if (e.type == TIMER){
		client->gameTime = e.score;
		printf("bole cene timer aldim %f\n", client->gameTime);
	}

	client->playerId = client->myEntity->eid;
	cout << "---------My id is: " << client->playerId << endl;
	client->recvEntity(client->myEntity);

	int i = 0;
	while (1){
		Entity *e = new Entity;
		*sc >> *e;
		
		if (!sc->isConnected()){
			cout << "Disconnected from server" << endl;
			break;
		}
		client->recvEntity(e);
		e = NULL;

	}

	return NULL;
}


/*
void Client::createNodeForNewComing(Entity *e){


	if (e->type == 1){
		IAnimatedMeshSceneNode* cube = NULL;

		printf("******** eid %d  get %d \n", e->eid, getPlayerEntity(e->eid)->eid);
		PlayerEntity * p = dynamic_cast<PlayerEntity*> (getPlayerEntity(e->eid));

		if (p->eid == 0)
			cube = smgr->addAnimatedMeshSceneNode(smgr->getMesh("../media/dwarf.x"), 0, (irr::s32)4);
		if (p->eid == 1){
			cube = smgr->addAnimatedMeshSceneNode(smgr->getMesh("../media/ninja.b3d"), 0, (irr::s32)4);
			cube->setScale(core::vector3df(10, 10, 10));
		}if (p->eid == 2)
			cube = smgr->addAnimatedMeshSceneNode(smgr->getMesh("../media/dwarf.x"), 0, (irr::s32)4);
		if (p->eid == 3)
			cube = smgr->addAnimatedMeshSceneNode(smgr->getMesh("../media/ninja.b3d"), 0, (irr::s32)4);


		cube->setMaterialFlag(EMF_LIGHTING, false);
		p->myNode = cube;

	}
	else{
		IMeshSceneNode *sphere;
		IAnimatedMeshSceneNode *mesh;

		ItemEntity * p = dynamic_cast<ItemEntity *> (e);
		sphere = smgr->addSphereSceneNode();
		char str[100];

		sprintf_s(str, "../media/item%d.png", p->score);
		sphere->setMaterialTexture(0, smgr->getVideoDriver()->getTexture(str));
		p->itemNode = sphere;

		printf("type: %d, score**********: %d\n", p->type, p->score);

	}

	cout << "Node created for" << e->eid << endl;
}
*/