#ifndef SERVER_H
#define SERVER_H

#include <iostream>
#include <pthread.h>

#ifdef _WIN32
#include <winsock.h>
#else
#include <unistd.h>     //socket(), accept(), listen(), bind(), send(), recv()
#include <netinet/in.h> //sockaddr_in, htons()
#endif

#include "SocketConnector.h"
#include "AbstractNetwork.h"
#include "imports.h"
#include <time.h>
#include <stdlib.h>

class Server : public AbstractNetwork{
public:
	Server(int port);
	~Server();

	void newClientComming(SocketConnector* elci);

	/* sekreter thread */
	static void* waitAccept(void* server);

	void sendEntity(Entity* entity);
	void recvEntity(Entity* entity);

	SocketConnector* waitClient();
	void createMeshFlagForNewNode(int eid, int type);

	
	/* her client i�in thread */
	static void* handleClient(void* serverClientData);

private:
	int fd; //for sekreter
	int port;
	pthread_t listenMySocket;
	/* B�t�n clientlar�n ileti�imi i�in */
	vector<SocketConnector*> socetConnectorArr;
	/* yeni baglanan , yaratilan entitiy e id verebilmek icin */
	int lastEntityId;
	pthread_mutex_t lock;
	int playerRoomCounter= 0;
	int playerRoomIndex = 0;
	/*elapsed time i  bulabilmek icin*/

	vector<Entity*> scoreArr;
	
};

struct ThreadData{
	Server* server;
	SocketConnector* sc;
	char name[50];
};

#endif // SERVER_H


