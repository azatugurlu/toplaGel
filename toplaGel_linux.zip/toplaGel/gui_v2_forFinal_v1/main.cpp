#include <iostream>
using namespace std;

#include <irrlicht.h>
using namespace irr;

using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;

#ifdef _IRR_WINDOWS_
#pragma comment(lib, "Irrlicht.lib")
#endif


#include "Game.h"
#include "ConnectMenu.h"

int main(int argc, char**argv){

	ConnectMenu menu;
	Game gyte;

	if (menu.run())
	{	
		gyte.type = menu.type;
		gyte.gameSceneInitiaize(menu.ipAddress);
		gyte.gameRun();
	}


	return 0;
}