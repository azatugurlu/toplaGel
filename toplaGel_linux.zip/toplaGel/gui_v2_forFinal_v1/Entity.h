#pragma once

#include <iostream>
using namespace std;

#include <irrlicht.h>
using namespace irr;

using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;

#include "SocketConnector.h"
#include "imports.h"


class Entity {
public:
	Entity();

	friend SocketConnector& operator<<(SocketConnector& sc, Entity& e);
	friend SocketConnector& operator>>(SocketConnector& sc, Entity& e);

	void updateNode();

	void update(Entity* e);

	int eid, type, meshFlag, score, index;
	float x, y, z;

	ISceneNode* node;
	IAnimatedMesh *meshNode;
	IAnimatedMeshSceneNode * sceneNode;
};

