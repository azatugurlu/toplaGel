#include "Entity.h"

Entity::Entity(){
	x = 0;
	y = -50;
	z = 0;
	type = 0;
	index = -1;

	eid = -1;

	node = NULL;
}



SocketConnector& operator<<(SocketConnector &sc , Entity& e){
	sc << e.type;
	sc << e.x;
	sc << e.y;
	sc << e.z;
	sc << e.eid;
	sc << e.meshFlag;
	sc << e.index;
	sc << e.score;

	return sc;
}

SocketConnector& operator>>(SocketConnector &sc, Entity& e){
	sc >> e.type;
	sc >> e.x;
	sc >> e.y;
	sc >> e.z;
	sc >> e.eid;
	sc >> e.meshFlag;
	sc >> e.index;
	sc >> e.score;


	return sc;
}

void Entity::updateNode(){
	if (node != NULL)
		node->setPosition(vector3df(x, y, z));
	if (sceneNode != NULL)
		sceneNode->setPosition(vector3df(x, y, z));

}

void Entity::update(Entity* e){
	x = e->x;
	y = e->y;
	z = e->z;
	eid = e->eid;
	index = e->index;

	updateNode();
}